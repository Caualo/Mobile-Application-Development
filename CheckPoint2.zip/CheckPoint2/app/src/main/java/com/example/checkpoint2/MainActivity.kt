//Declarando o pacote onde esta localizada a classe do app/budleID
package com.example.checkpoint2
//importando as bibliotecas necesarias
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import android.widget.Toast
import android.content.Intent

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Define o layout da tela usando o arquivo de layout
        setContentView(R.layout.activity_main)

        //Encontra o botão na interface do usuario utilizando o ID button
        val buttonAluno = findViewById<Button>(R.id.buttonAluno)

        //Definindo ouvinte de click para o botão
        buttonAluno.setOnClickListener {
            // Exibe uma mensagem Toast
            Toast.makeText(this, "Cauã Ferrigolli Loureiro, RM553093, 2TDSPT", Toast.LENGTH_LONG).show()


            val buttonCalc = findViewById<Button>(R.id.buttonCalc)
                buttonCalc.setOnClickListener {
                    val intent = Intent(this, MainActivityCalc::class.java)
                    startActivity(intent)
                }
        }
    }
}





