package com.example.checkpoint2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Toast
import android.widget.EditText
import android.widget.RadioButton
import android.widget.Button


class MainActivityCalc : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //Define o layout da tela usando o arquivo de layout
        setContentView(R.layout.activity_main_calc)



        val num1Field: EditText = findViewById(R.id.editTextNumber)
        val num2Field: EditText = findViewById(R.id.editTextNumber2)
        val somaButton: RadioButton = findViewById(R.id.radioButtonSo)
        val subtracaoButton: RadioButton = findViewById(R.id.radioButtonSub)
        val multiplicacaoButton: RadioButton = findViewById(R.id.radioButtonMult)
        val divisaoButton: RadioButton = findViewById(R.id.radioButtonDiv)
        val calcularButton: Button = findViewById(R.id.button)

        // Ação ao clicar no botão de calcular
        calcularButton.setOnClickListener {
            // Verificar se os campos estão preenchidos
            if (num1Field.text.isNotEmpty() && num2Field.text.isNotEmpty()) {
                val num1 = num1Field.text.toString().toDouble()
                val num2 = num2Field.text.toString().toDouble()
                var result = 0.0

                // Verificar qual operação foi selecionada
                when {
                    somaButton.isChecked -> result = num1 + num2
                    subtracaoButton.isChecked -> result = num1 - num2
                    multiplicacaoButton.isChecked -> result = num1 * num2
                    divisaoButton.isChecked -> {
                        if (num2 != 0.0) {
                            result = num1 / num2
                        } else {
                            Toast.makeText(this, "Erro: Divisão por zero!", Toast.LENGTH_LONG).show()
                            return@setOnClickListener
                        }
                    }
                    else -> {
                        Toast.makeText(this, "Selecione uma operação!", Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }
                }

                // Exibir o resultado
                Toast.makeText(this, "Resultado: $result", Toast.LENGTH_LONG).show()
            } else {
                // Mostrar mensagem de erro se algum campo estiver vazio
                Toast.makeText(this, "Preencha ambos os números!", Toast.LENGTH_LONG).show()
            }
        }
    }
}


